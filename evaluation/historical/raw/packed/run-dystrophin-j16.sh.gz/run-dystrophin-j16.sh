#!/usr/bin/env bash
set -euo pipefail

ROOT=/common/home/jy512/dev/rna
OUT="$ROOT/research/results/packed-layout-2026-07-14"
FROZEN=/tmp/ldclean-packed-final-20260714
BINDER="$ROOT/research/results/numabind0-epyc-0bbada9fb6e1"
PROTEIN="$ROOT/research/data/NP_000100.3_dystrophin_Dp427c.fasta"
CODON="$ROOT/lineardesign-clean/data/codon_usage_freq_table_human.csv"
GNU_TIME=/usr/bin/time

export LC_ALL=C
export OMP_PROC_BIND=close
export OMP_PLACES=cores
export OMP_DYNAMIC=false
export OMP_WAIT_POLICY=active
export OMP_THREAD_LIMIT=16

for dependency in \
    "$FROZEN/cost-B" "$FROZEN/cost-D" "$FROZEN/lineardesign-D" \
    "$BINDER" "$PROTEIN" "$CODON" "$GNU_TIME"; do
    test -r "$dependency"
done

cp "$FROZEN/SOURCE_SHA256SUMS" "$OUT/frozen-SOURCE_SHA256SUMS"
cp "$FROZEN/BIN_SHA256SUMS" "$OUT/frozen-BIN_SHA256SUMS"
cp "$FROZEN/BUILD_FLAGS" "$OUT/frozen-BUILD_FLAGS"
cp "$FROZEN/VALIDATION" "$OUT/frozen-VALIDATION"
cp "$FROZEN/MANIFEST_SHA256SUMS" "$OUT/frozen-MANIFEST_SHA256SUMS"

record_before() {
    local label=$1
    local binary=$2
    {
        date --utc --iso-8601=seconds
        uptime
        sha256sum "$binary" "$BINDER" "$PROTEIN" "$CODON"
        "$BINDER" /bin/sh -c 'taskset -pc "$$"'
        vmstat 1 2
    } > "$OUT/$label.meta"
}

record_after() {
    local label=$1
    {
        date --utc --iso-8601=seconds
        uptime
    } >> "$OUT/$label.meta"
}

run_cost() {
    local label=$1
    local binary=$2
    test ! -e "$OUT/$label.out"
    test ! -e "$OUT/$label.time"
    test ! -e "$OUT/$label.err"
    record_before "$label" "$binary"
    "$GNU_TIME" -v -o "$OUT/$label.time" \
        env OMP_PROC_BIND="$OMP_PROC_BIND" OMP_PLACES="$OMP_PLACES" \
            OMP_DYNAMIC="$OMP_DYNAMIC" OMP_WAIT_POLICY="$OMP_WAIT_POLICY" \
            OMP_THREAD_LIMIT="$OMP_THREAD_LIMIT" \
        "$BINDER" "$binary" --mode sparse -l 0 -j 16 -c "$CODON" "$PROTEIN" \
        > "$OUT/$label.out" 2> "$OUT/$label.err"
    test ! -s "$OUT/$label.err"
    record_after "$label"
}

run_full() {
    local label=$1
    local binary=$2
    test ! -e "$OUT/$label.out"
    test ! -e "$OUT/$label.time"
    test ! -e "$OUT/$label.err"
    record_before "$label" "$binary"
    "$GNU_TIME" -v -o "$OUT/$label.time" \
        env OMP_PROC_BIND="$OMP_PROC_BIND" OMP_PLACES="$OMP_PLACES" \
            OMP_DYNAMIC="$OMP_DYNAMIC" OMP_WAIT_POLICY="$OMP_WAIT_POLICY" \
            OMP_THREAD_LIMIT="$OMP_THREAD_LIMIT" \
        "$BINDER" "$binary" -l 0 -j 16 -c "$CODON" \
        < "$PROTEIN" > "$OUT/$label.out" 2> "$OUT/$label.err"
    test ! -s "$OUT/$label.err"
    record_after "$label"
}

# Counterbalanced adjacent layout comparison: square, packed, packed, square.
run_cost dmd-01-B-square "$FROZEN/cost-B"
run_cost dmd-02-D-packed "$FROZEN/cost-D"
run_cost dmd-03-D-packed "$FROZEN/cost-D"
run_cost dmd-04-B-square "$FROZEN/cost-B"

# One production-interface packed run, retained for full translation/energy validation.
run_full dmd-05-D-packed-full "$FROZEN/lineardesign-D"

sha256sum "$OUT"/dmd-* > "$OUT/SHA256SUMS"

# Packed forward-memo layout: dystrophin `j16` run record

Status: complete exploratory same-source comparison, 2026-07-14. The strict analyzer accepts the
entire archive. The host was shared and visibly loaded, and there are only two runs per layout, so
the timing result is a design decision measurement rather than a publication-quality confidence
interval. The whole-process RSS result is stable across both adjacent pairs and agrees with the
exact ABI accounting.

## Experimental boundary

The input is human dystrophin Dp427c, RefSeq `NP_000100.3` (3,677 aa / 11,031 coding nt), at
`lambda=0` and `j16`. Both cost binaries were built from the same source snapshot with GCC 11.4.0,
`-std=c++11 -O3 -flto -Wall -fopenmp`; they differ only by layout macros:

- **B-square:** full `N*N` memo arena with same-layer base cases preseeded; and
- **D-packed:** stable position-major DFA IDs and the default forward-only memo arena.

The source manifest has SHA-256
`f63f19747ce97d7ca95a7d4dc93ae5998cafcbdda8d072190f7489cf53128d44`. Cost binaries B and D have
SHA-256 `fb273c580ff8804c1f2cf7b761034dec71cc54b2fcb2fe2a195e29819b8105f3` and
`a06b5b0973a4cf6218d217c6cbe0ab171c65d85a437cbd875566be212247689e`. The full D CLI binary has
SHA-256 `e2941bf2d53021bc517e99ef6ab7e59dbf6cd724778181b079f8810e8ef8913e`.

All runs used the same node-0 CPU/memory binder, codon table, OpenMP environment, and input. The
cost-run order was counterbalanced `B,D,D,B`; a full D CLI run followed. Requested and observed
cost-harness team sizes were both 16. Raw per-run stdout, empty stderr, GNU-time resources, load and
affinity metadata, frozen build manifests, and their 20-file checksum manifest are in
[`packed-layout-2026-07-14/`](packed-layout-2026-07-14/). The exact runner is
[`run-dystrophin-j16.sh`](packed-layout-2026-07-14/run-dystrophin-j16.sh), SHA-256
`97c707d56e490dfac0afd86d4dbb8bb7276507076c8a3ffac6c131e4a186fc45`.

## Result

Every cost run returned the identical objective `-716140` centi-kcal/mol.

| Layout | n | Median solve | Median wall | Median peak RSS |
|---|---:|---:|---:|---:|
| B-square | 2 | 237.864 s | 238.87 s | 20.083 GiB |
| D-position-major packed | 2 | 257.320 s | 258.33 s | 14.417 GiB |

Packed/square is `1.081796` for solve time and `0.717873` for RSS: the packed layout was 8.18%
slower in this sequence but saved 5.666 GiB, or 28.21% of total peak RSS. The adjacent-pair solve
ratios were `1.082990` and `1.080598`; RSS savings were 5,940,836 and 5,941,300 KiB. Thus neither
effect is an order artifact in these runs, although shared-host timing remains exploratory.

The memory delta is predicted without fitting. Dystrophin has `N=12,824`,
`S=sum_p w_p^2=16,408`, and

`F=(N^2+S)/2=82,235,692`

stored forward cells. On the measured LP64 ABI, square fixed payload is `74N^2 = 12,169,668,224`
bytes and packed fixed payload plus row offsets is `74F+8N = 6,085,543,800` bytes. Their difference
is 6,084,124,424 bytes = 5.6663 GiB, matching the median whole-process RSS saving to rounding. The
layout halves the fixed arena asymptotically for bounded layer width but remains `O(N^2)`.

## Full output validation

The full packed CLI run completed in 238.86 s at 14.428 GiB peak RSS and produced stdout SHA-256
`61d9df110022fa43803ad969df3618a5ee49a7a4eb098afedef44c8ce2f28752`. Independent validation
passes every check: 11,031-nt CDS and structure lengths, exact translation to the 3,677-aa source,
canonical/balanced base pairs, the 30-unpaired two-loop cap, recomputed CAI
`0.7340016904117271`, and independently reevaluated Turner energy `-716140` centi-kcal/mol
(`-7161.40` kcal/mol). The CDS and structure SHA-256 values are
`215ec6ff42423dbfa18e2b49ffa30df79e4c6dc49d0e93c5088f23db6e619fcf` and
`b9eb52ecec610e327fc23a669a4365a86ab14e2a0b6be21260a5396db4581421`.

Machine-readable and review reports are
[`packed-layout-2026-07-14-summary.json`](packed-layout-2026-07-14-summary.json),
[`packed-layout-2026-07-14-summary.md`](packed-layout-2026-07-14-summary.md),
[`packed-layout-2026-07-14-validation.json`](packed-layout-2026-07-14-validation.json), and
[`packed-layout-2026-07-14-validation.md`](packed-layout-2026-07-14-validation.md). The strict
analyzer is [`../analyze_packed_layout.py`](../analyze_packed_layout.py), SHA-256
`cc82bd0245e7eacaeabb538c57588408199e3a52dbde7df89f8cd7a0587eeb1e`.

## Interpretation

Forward-only packing is a validated memory mode, not a free speedup. It addresses the unchanged
quadratic memo floor around sparse multiloop candidates; it does not change candidate count `Z` or
the `O(N+Z)` candidate-index bound. This B/D result motivated a follow-up compact-container/hybrid
layout screen before selecting the release default. Do not combine the 8.18% layout cost with the
historical sparse-versus-dense multiloop speedup, and do not overwrite the separate July 13
historical dystrophin archive.

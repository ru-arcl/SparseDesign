# LinearDesign output validation

- Status: **PASS**
- Record: `NP_000100.3 dystrophin isoform Dp427c [Homo sapiens]`
- Evaluator provenance: packed-stage evaluator; source manifest f63f19747ce97d7ca95a7d4dc93ae5998cafcbdda8d072190f7489cf53128d44
- Lengths: 3677 aa; 11031-nt CDS; 11031-nt structure
- MFE: printed `-7161.40`; reevaluated from the emitted design `-7161.40` kcal/mol
- CAI: printed `0.734`; recomputed `0.73400169041172714`

## SHA-256

| Artifact | SHA-256 |
|---|---|
| protein input | `8bddb035f39b0dc2bb6c0e49656c170ad0da417bc814bd0f568922796d58cbf4` |
| solver output | `61d9df110022fa43803ad969df3618a5ee49a7a4eb098afedef44c8ce2f28752` |
| evaluator | `2ee5a0482e8d0d976e237e12dad3e475a1efcb1285416fcbc7e0b18b9799f3f6` |
| codon table | `e6c4a49036fe21f3266e7e53130011bd7725c62ebeabbe442f7f8f1cdf5890c4` |

## Checks

| Check | Result | Detail |
|---|---:|---|
| reported_mfe_precision | PASS | two digits after the decimal point |
| reported_cai_precision | PASS | three digits after the decimal point |
| protein_alphabet | PASS | all residues are defined by the codon table |
| canonical_rna | PASS | uppercase A/C/G/U only |
| cds_codon_length | PASS | 11031 nt is divisible by 3 |
| cds_protein_length | PASS | expected 11031 nt; observed 11031 nt |
| structure_length | PASS | CDS 11031 nt; structure 11031 nt |
| dot_bracket_alphabet | PASS | dot, opening parenthesis, and closing parenthesis only |
| dot_bracket_balance | PASS | balanced |
| canonical_base_pairs | PASS | all 4449 base pairs are canonical Watson-Crick or G-U pairs |
| minimum_pair_span | PASS | every base pair encloses at least 3 nucleotides |
| two_loop_size_cap | PASS | every one-child loop has at most 30 unpaired nucleotides |
| codons_in_table | PASS | all codons are defined |
| translation | PASS | CDS translates exactly to the source protein |
| reported_cai_rounding | PASS | recomputed 0.73400169041172714; printed 0.734; absolute difference 1.6904117271510088e-06 <= 0.00050000000000088819 |
| reported_mfe_rounding | PASS | recomputed -7161.40 (-716140 centi-kcal/mol); printed -7161.40; absolute difference 0 <= 0.0050000000072759577 |

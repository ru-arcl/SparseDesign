# LinearDesign output validation

- Status: **PASS**
- Record: `seq1`
- Evaluator provenance: Adapter SHA-256 59b9a16a85095219761200aea287ec681b3653af5728886876ade260c1f1b5d0 linked with v0039 git commit 72e2a1a9042fe46d7700fd9a590ebf01b3bc0f3a sources; GCC 11.4.0, -std=c++11 -O3 -fopenmp. The clean and local dense energy modules were independently checked against the same original LinearDesign Turner-d0 oracle (54,320/54,320 and 55,517/55,517), so this evaluator applies to both outputs.
- Lengths: 3677 aa; 11031-nt CDS; 11031-nt structure
- MFE: printed `-7161.40`; reevaluated from the emitted design `-7161.40` kcal/mol
- CAI: printed `0.734`; recomputed `0.73400169041172714`

## SHA-256

| Artifact | SHA-256 |
|---|---|
| protein input | `c8ee41bc904f43563d18f78c2f05ba4edf6d5fbe08c0f3fff963d8ee4b85e5e2` |
| solver output | `bf14bdcc18f0245c8289efdfa9759e0c48e80b3090d40d273c033b8b71cc0980` |
| evaluator | `4b7cdc5ff5641908d902632afd7a3ea6162b2dfee413bd8356a39ecba5cbd1ae` |
| codon table | `e6c4a49036fe21f3266e7e53130011bd7725c62ebeabbe442f7f8f1cdf5890c4` |

## Checks

| Check | Result | Detail |
|---|---:|---|
| reported_mfe_precision | PASS | two digits after the decimal point |
| reported_cai_precision | PASS | three digits after the decimal point |
| protein_alphabet | PASS | all residues are defined by the codon table |
| canonical_rna | PASS | uppercase A/C/G/U only |
| cds_codon_length | PASS | 11031 nt is divisible by 3 |
| cds_protein_length | PASS | expected 11031 nt; observed 11031 nt |
| structure_length | PASS | CDS 11031 nt; structure 11031 nt |
| dot_bracket_alphabet | PASS | dot, opening parenthesis, and closing parenthesis only |
| dot_bracket_balance | PASS | balanced |
| canonical_base_pairs | PASS | all 4449 base pairs are canonical Watson-Crick or G-U pairs |
| minimum_pair_span | PASS | every base pair encloses at least 3 nucleotides |
| two_loop_size_cap | PASS | every one-child loop has at most 30 unpaired nucleotides |
| codons_in_table | PASS | all codons are defined |
| translation | PASS | CDS translates exactly to the source protein |
| reported_cai_rounding | PASS | recomputed 0.73400169041172714; printed 0.734; absolute difference 1.6904117271510088e-06 <= 0.00050000000000088819 |
| reported_mfe_rounding | PASS | recomputed -7161.40 (-716140 centi-kcal/mol); printed -7161.40; absolute difference 0 <= 0.0050000000072759577 |

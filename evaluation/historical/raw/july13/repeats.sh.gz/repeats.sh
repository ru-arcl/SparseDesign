#!/bin/bash
# 5x clean -j16 on dystrophin, each NUMA-bound to a RANDOM node (0 or 1); take the best wall time.
# Purpose: mitigate shared-machine load noise on the headline -j16 number.
DYST="/common/home/jy512/linear-design/LinearDesign/dystseq"; CLEAN="/common/home/jy512/dev/rna/lineardesign-clean/lineardesign-clean"; CLEANTBL="/common/home/jy512/dev/rna/lineardesign-clean/data/codon_usage_freq_table_human.csv"; OUT=/tmp/dystbench; NB=$OUT/numabind
hb(){ echo "[$(date '+%m-%d %H:%M:%S')] $*" | tee -a $OUT/progress.log; }
hb "===== clean -j16 best-of-5 (random node) START ====="
for r in 1 2 3 4 5; do
  o=$OUT/rep${r}.out; t=$OUT/rep${r}.time
  if grep -qi 'free energy' "$o" 2>/dev/null; then hb "repeat $r already done, skip"; continue; fi
  node=$((RANDOM % 2))
  hb "START repeat $r on node$node"
  /usr/bin/time -v $NB $node "$CLEAN" -l 0 -c "$CLEANTBL" -j 16 < "$DYST" > $o 2> $t
  hb "DONE  repeat $r on node$node : $(grep -i Elapsed $t | grep -oE '[0-9:.]+$')  MFE=$(grep -aoE 'free energy: *-?[0-9.]+' $o|tail -1)"
done
hb "===== repeats DONE ====="
# summarize best
python3 - <<'PY'
import re,glob
best=None; rows=[]
for f in sorted(glob.glob('/tmp/dystbench/rep*.time')):
    txt=open(f).read()
    m=re.search(r'Elapsed.*?:\s*([0-9:.]+)',txt); 
    if not m: continue
    s=m.group(1); p=s.split(':'); sec=float(p[0])*60+float(p[1]) if len(p)==2 else float(p[0])*3600+float(p[1])*60+float(p[2])
    hb=[l for l in open('/tmp/dystbench/progress.log') if f.split('/')[-1].replace('.time','') in l]
    rows.append((f.split('/')[-1],s,sec))
for n,s,sec in rows: print(f"  {n}: {s} ({sec:.1f}s)")
if rows:
    bn,bs,bsec=min(rows,key=lambda x:x[2]); print(f"BEST: {bs} ({bsec:.1f}s) [{bn}]")
PY

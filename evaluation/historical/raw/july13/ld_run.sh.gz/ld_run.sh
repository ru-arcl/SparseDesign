#!/bin/bash
# Corrected lineardesign ladder: run FROM lineardesign/ so ./coding_wheel.txt resolves.
# NUMA-bound to node0 via numabind0. Resumable. ~400GB each.
cd /common/home/jy512/dev/rna/lineardesign || exit 1
DYST="/common/home/jy512/linear-design/LinearDesign/dystseq"; OUT=/tmp/dystbench; NB=$OUT/numabind0
hb(){ echo "[$(date '+%m-%d %H:%M:%S')] $*" | tee -a $OUT/progress.log; }
done_ok(){ grep -qi 'free energy' "$1" 2>/dev/null; }
n0(){ awk '/MemFree|FilePages|SReclaimable/{s+=$4}END{printf "%.0f",s/1048576}' /sys/devices/system/node/node0/meminfo; }
for j in 16 8 4 2 1; do
  o=$OUT/ld_j$j.out; t=$OUT/ld_j$j.time
  if done_ok "$o"; then hb "ld -j$j already done, skip"; continue; fi
  hb "node0 reclaim+free ~$(n0) GB before ld -j$j (needs ~400)"
  hb "START ld -j$j (cwd=lineardesign)"
  /usr/bin/time -v $NB ./bin/LinearDesign_2D 0 0 ./codon_usage_freq_table_human.csv $j < "$DYST" > $o 2> $t
  if done_ok "$o"; then hb "DONE  ld -j$j : $(grep -i Elapsed $t|grep -oE '[0-9:.]+$')  RSS=$(grep -i 'Maximum resident' $t|grep -oE '[0-9]+')kB  $(grep -aoE 'free energy: *-?[0-9.]+' $o|tail -1)"
  else hb "FAIL  ld -j$j"; fi
done
hb "===== lineardesign re-run DONE ====="

#!/bin/bash
# Resumable dystrophin benchmark, clean(v0039) + lineardesign, j16/j8/j4/j2/j1.
# Every run NUMA-bound to node0 (CPUs 0-15 + memory) via numabind0.
DYST="/common/home/jy512/linear-design/LinearDesign/dystseq"; CLEAN="/common/home/jy512/dev/rna/lineardesign-clean/lineardesign-clean"; CLEANTBL="/common/home/jy512/dev/rna/lineardesign-clean/data/codon_usage_freq_table_human.csv"; LD="/common/home/jy512/dev/rna/lineardesign/bin/LinearDesign_2D"; LDTBL="/common/home/jy512/dev/rna/lineardesign/codon_usage_freq_table_human.csv"
OUT=/tmp/dystbench; NB=$OUT/numabind0
hb(){ echo "[$(date '+%m-%d %H:%M:%S')] $*" | tee -a $OUT/progress.log; }
done_ok(){ grep -qi 'free energy' "$1" 2>/dev/null; }   # design completed => has MFE line
node0_free_gb(){ awk '/MemFree|FilePages|SReclaimable/{s+=$4}END{printf "%.0f",s/1048576}' /sys/devices/system/node/node0/meminfo; }

run(){ local tool=$1 j=$2; local o=$OUT/${tool}_j$j.out t=$OUT/${tool}_j$j.time
  if done_ok "$o"; then hb "$tool -j$j already done, skip"; return; fi
  if [ "$tool" = ld ]; then hb "node0 reclaimable+free ~$(node0_free_gb) GB before ld -j$j (needs ~400)"; fi
  hb "START $tool -j$j"
  if [ "$tool" = clean ]; then
    /usr/bin/time -v $NB "$CLEAN" -l 0 -c "$CLEANTBL" -j $j < "$DYST" > $o 2> $t
  else
    /usr/bin/time -v $NB "$LD" 0 0 "$LDTBL" $j < "$DYST" > $o 2> $t
  fi
  if done_ok "$o"; then hb "DONE  $tool -j$j : $(grep -i Elapsed $t | grep -oE '[0-9:.]+$')  RSS=$(grep -i 'Maximum resident' $t | grep -oE '[0-9]+')kB"
  else hb "FAIL  $tool -j$j (no MFE in output — see $t)"; fi
}
hb "===== benchmark start (clean v0039 first, then lineardesign) ====="
for j in 16 8 4 2 1; do run clean $j; done
for j in 16 8 4 2 1; do run ld    $j; done
hb "===== benchmark ALL DONE ====="

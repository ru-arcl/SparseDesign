#!/bin/bash
# node0 vs node1 systematic-difference check: clean -j8 and -j4, both nodes, INTERLEAVED
# (node0 then node1 back-to-back per config+rep => matched ambient load), 3 reps.
DYST="/common/home/jy512/linear-design/LinearDesign/dystseq"; CLEAN="/common/home/jy512/dev/rna/lineardesign-clean/lineardesign-clean"; CLEANTBL="/common/home/jy512/dev/rna/lineardesign-clean/data/codon_usage_freq_table_human.csv"; OUT=/tmp/dystbench; NB=$OUT/numabind
hb(){ echo "[$(date '+%m-%d %H:%M:%S')] $*" | tee -a $OUT/progress.log; }
done_ok(){ grep -qi 'free energy' "$1" 2>/dev/null; }
hb "===== node0-vs-node1 comparison (clean j8,j4; 3 reps interleaved) START ====="
for rep in 1 2 3; do
  for j in 8 4; do
    for node in 0 1; do
      o=$OUT/nc_j${j}_n${node}_r${rep}.out; t=$OUT/nc_j${j}_n${node}_r${rep}.time
      if done_ok "$o"; then hb "nc j$j node$node rep$rep skip"; continue; fi
      hb "START nc j$j node$node rep$rep"
      /usr/bin/time -v $NB $node "$CLEAN" -l 0 -c "$CLEANTBL" -j $j < "$DYST" > $o 2> $t
      hb "DONE  nc j$j node$node rep$rep : $(grep -i Elapsed $t|grep -oE '[0-9:.]+$')  $(grep -aoE 'free energy: *-?[0-9.]+' $o|tail -1)"
    done
  done
done
hb "===== node comparison DONE ====="

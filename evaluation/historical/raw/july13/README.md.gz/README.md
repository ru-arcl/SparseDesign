# Dystrophin exact-solver benchmark archive (2026-07-13)

This directory preserves the raw standard output, GNU `time -v` logs, and launch scripts behind the
July 13 EPYC dystrophin comparison. The historical benchmark files were copied byte-for-byte from
`/tmp/dystbench` before that temporary directory was cleaned. Four deterministic validation reports
were added on July 14. `SHA256SUMS` covers all 70 non-manifest files.

## Input and objective

- Protein: human dystrophin Dp427c, NCBI RefSeq `NP_000100.3`, 3,677 aa / 11,031 coding nt.
- Historical input file SHA-256: `c8ee41bc904f43563d18f78c2f05ba4edf6d5fbe08c0f3fff963d8ee4b85e5e2`.
- Normalized amino-acid SHA-256: `c0b35a4bba1c1cece0cb576cbf1302a2047b94bbe218844e692cfcde480ff2f6`.
- Objective: exact Turner dangle-0 design at lambda 0 with the archived human codon table.
- All archived successful runs report MFE `-7161.40` kcal/mol. The clean solver chooses CAI
  `0.734`; the local dense comparator chooses CAI `0.762`. CAI is outside the lambda-zero objective,
  so this is a tie-order difference rather than an objective disagreement.

`historical-dystseq.fasta` is the exact file read by the scripts. The accession-labelled copy in
`research/data/NP_000100.3_dystrophin_Dp427c.fasta` has a different header/wrapping but the same
normalized sequence. This is Dp427c, not the current 3,685-aa UniProt Dp427m entry.

## Executables and host

- Clean sparse executable: `lineardesign-clean-881bf4513e51`, SHA-256
  `881bf4513e51a6195687f96972972f980872ea58135dc56f994bcf6958ccbccf`.
- Dense comparator: `LinearDesign_2D-local-openmp-50040b7e7956`, SHA-256
  `50040b7e7956c8c69358a992762a82909d5b0361acd8a0d0ff4f5c920ba2bcbe`.
- Codon table SHA-256: `e6c4a49036fe21f3266e7e53130011bd7725c62ebeabbe442f7f8f1cdf5890c4`.
- Host: `arrakis.cs`, dual-socket AMD EPYC 7313, 16 physical cores per socket, no SMT, two NUMA
  nodes, 1 TiB RAM; GCC/G++ 11.4.0.
- Every primary ladder run was bound to node 0 CPUs and memory. The exact historical node-0 helper
  is `research/tools/numabind0_epyc.c` (SHA-256
  `d4c3d27e0fd2278905703f68c5316ae376f10edba30a6739b751014be0176beb`). The node-selectable helper
  used for the repeats is `research/tools/numabind_epyc.c` (SHA-256
  `69f11cc783888a363c5e331ba4c59c15c090b3c7a6874c537e4a60e3318fba71`). Both hard-code this
  machine's CPU-to-node layout and must not be used elsewhere without an audit.

The dense executable is **not** stock upstream parallel LinearDesign. It is the dense LinearDesign
parser with this repository's local OpenMP patches (source commit `0e201558703c9d7bda004279807f0d03a305a37f`).
Stock upstream is serial. The one-thread row is the cleanest algorithm comparison; multi-thread rows
compare two local implementations and include very different memory-bandwidth behavior.

## Primary raw results

| Solver | Threads | Wall | CPU | Max RSS KiB | Max RSS GiB |
| --- | ---: | ---: | ---: | ---: | ---: |
| clean sparse | 1 | 39:37.35 | 99% | 21,073,816 | 20.10 |
| clean sparse | 2 | 22:38.03 | 198% | 21,075,844 | 20.10 |
| clean sparse | 4 | 12:21.01 | 392% | 21,080,004 | 20.10 |
| clean sparse | 8 | 6:51.49 | 769% | 21,088,776 | 20.11 |
| clean sparse | 16 | 5:45.62 | 1422% | 21,105,896 | 20.13 |
| local dense fork | 1 | 1:21:52 | 99% | 421,630,724 | 402.10 |
| local dense fork | 2 | 1:36:26 | 180% | 420,206,908 | 400.74 |
| local dense fork | 4 | 57:54.19 | 303% | 420,622,932 | 401.14 |
| local dense fork | 8 | 42:41.40 | 488% | 420,032,352 | 400.57 |
| local dense fork | 16 | 43:32.20 | 796% | 420,575,704 | 401.09 |

The host was shared and intermittently contended. In particular, the dense `j2` slowdown is not an
algorithmic result. Use the raw `.time` files, not rounded values in this README, for reanalysis.

## Clean `j16` repeats

Five additional `j16` runs were bound to a pseudorandomly chosen node. `progress.log` records the
node assignments.

| Run | Node | Wall | CPU | Max RSS KiB |
| --- | ---: | ---: | ---: | ---: |
| `rep1` | 1 | 3:55.32 | 1456% | 21,105,328 |
| `rep2` | 0 | 5:18.22 | 1423% | 21,105,144 |
| `rep3` | 0 | 5:42.13 | 1418% | 21,104,892 |
| `rep4` | 1 | **3:52.58** | 1467% | 21,105,088 |
| `rep5` | 0 | 5:40.09 | 1418% | 21,105,412 |

The published endpoint uses the explicitly labelled best of five, `rep4`. All five measurements
are retained so a reader can apply another aggregation. The node-0/node-1 interleaved comparison
(`nc_*`) found nearly identical performance at `j4` and `j8`; the larger node difference in these
five runs is therefore attributed to transient contention, not a stable socket advantage.

## File map and cautions

- `clean_j*.out/.time`: primary clean thread ladder.
- `ld_j*.out/.time`: primary local dense-fork thread ladder.
- `rep*.out/.time`: five clean `j16` repeats.
- `nc_j*_n*_r*.out/.time`: three interleaved node comparisons at `j4` and `j8`.
- `run.sh`, `ld_run.sh`, `repeats.sh`, `nodecmp.sh`: exact historical orchestration scripts.
- `progress.log`: wall-clock ordering, node assignments, and completion summaries.
- `clean_j16.validation.{json,md}` and `ld_j16.validation.{json,md}`: independent translation,
  length, CAI, and Turner-energy validation of the two full outputs.
- the two executables, two codon-table copies, `coding_wheel.txt`, and
  `historical-dystseq.fasta`: frozen run dependencies.

The read-only analyzer `research/analyze_dystrophin_bench.py` validates all 27 output/time pairs,
their exact historical grid and commands, and their common reported MFE; it generates
`research/results/dystrophin-2026-07-13-summary.{csv,md}` outside this raw archive. Independent
Turner reevaluation is supplied by the two `j16` validation reports, not by that log analyzer.

The scripts contain historical absolute paths and should be read as provenance, not executed
unchanged. The measurements compare the complete solver stacks; they do not isolate the sparse
multiloop recurrence. Use `research/tools/sparse_ablation.cc` and
`research/collect_sparse_ablation.py` for the controlled same-source ablation.

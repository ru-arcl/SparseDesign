# LinearDesign output validation

- Status: **PASS**
- Record: `NP_000100.3 dystrophin isoform Dp427c [Homo sapiens]`
- Lengths: 3677 aa; 11031-nt CDS; 11031-nt structure
- MFE: printed `-7161.40`; reevaluated from the emitted design `-7161.40` kcal/mol
- CAI: printed `0.762`; recomputed `0.76238741401792753`

## SHA-256

| Artifact | SHA-256 |
|---|---|
| protein input | `8bddb035f39b0dc2bb6c0e49656c170ad0da417bc814bd0f568922796d58cbf4` |
| solver output | `e42995562bbde60f9f118b1217380325e8915a86c96322243aa75292b47b446c` |
| evaluator | `2ee5a0482e8d0d976e237e12dad3e475a1efcb1285416fcbc7e0b18b9799f3f6` |
| codon table | `e6c4a49036fe21f3266e7e53130011bd7725c62ebeabbe442f7f8f1cdf5890c4` |

## Checks

| Check | Result | Detail |
|---|---:|---|
| reported_mfe_precision | PASS | two digits after the decimal point |
| reported_cai_precision | PASS | three digits after the decimal point |
| protein_alphabet | PASS | all residues are defined by the codon table |
| canonical_rna | PASS | uppercase A/C/G/U only |
| cds_codon_length | PASS | 11031 nt is divisible by 3 |
| cds_protein_length | PASS | expected 11031 nt; observed 11031 nt |
| structure_length | PASS | CDS 11031 nt; structure 11031 nt |
| dot_bracket_alphabet | PASS | dot, opening parenthesis, and closing parenthesis only |
| dot_bracket_balance | PASS | balanced |
| canonical_base_pairs | PASS | all 4449 base pairs are canonical Watson-Crick or G-U pairs |
| minimum_pair_span | PASS | every base pair encloses at least 3 nucleotides |
| two_loop_size_cap | PASS | every one-child loop has at most 30 unpaired nucleotides |
| codons_in_table | PASS | all codons are defined |
| translation | PASS | CDS translates exactly to the source protein |
| reported_cai_rounding | PASS | recomputed 0.76238741401792753; printed 0.762; absolute difference 0.00038741401792752317 <= 0.00050000000000088819 |
| reported_mfe_rounding | PASS | recomputed -7161.40 (-716140 centi-kcal/mol); printed -7161.40; absolute difference 0 <= 0.0050000000072759577 |

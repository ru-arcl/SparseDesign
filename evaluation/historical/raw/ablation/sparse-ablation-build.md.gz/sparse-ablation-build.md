# Historical same-source sparse/dense ablation build provenance

This note records the earlier packed-default harness. The completed matrix uses the final
square-default rebuild documented in [`sparse-ablation-final-square-build.md`](sparse-ablation-final-square-build.md).

Status: historical build record retained for provenance; it is not the build identity of the
completed square-default matrix.

[`sparse-ablation-build-SHA256SUMS`](sparse-ablation-build-SHA256SUMS), SHA-256
`9f89c03c17c0c20baa717122bd6ed2a4b187c054df6cc2a5e18b25de5e118193`, verifies the frozen
executables, raw compiler/linkage/hardware records, benchmark tools, binding source, and codon table
from the repository root. It also fixes every linked solver source/header used to build the harness.

## Executables

| Artifact | SHA-256 |
|:--|:--|
| [`sparse-ablation-harness-9c77cd1b2d3e`](sparse-ablation-harness-9c77cd1b2d3e) | `9c77cd1b2d3ecaae2d0a80502cf4a0f3ef48c23e1aaed24d5dd054d0ba93bf54` |
| [`numabind0-epyc-0bbada9fb6e1`](numabind0-epyc-0bbada9fb6e1) | `0bbada9fb6e1dda5db30ae218ad0685a371578d80c3c3fae16cac1d73aac8177` |
| GNU `/usr/bin/time` | `7310b9b4c51a8f4d26c1af0da250f03a49ec8a8141033123e79196ad18f6c81b` |

The binding executable hard-codes arrakis's node-0 CPU set (0--15) and Linux memory-policy call. It
must not be reused on another topology without source review and recompilation. A successful
collector row requires empty child stderr; any affinity/memory-policy `perror` output is therefore
fatal even if a wrapper were to return zero.

## Build

```bash
g++ -std=c++11 -O3 -flto -Wall -fopenmp -Ilineardesign-clean/src \
  research/tools/sparse_ablation.cc \
  lineardesign-clean/src/fold_turner.cc \
  lineardesign-clean/src/energy.cc \
  lineardesign-clean/src/dfa.cc \
  lineardesign-clean/src/codon_table.cc \
  -o /tmp/sparse_ablation-final

cc -O2 research/tools/numabind0_epyc.c -o /tmp/numabind0_epyc-current
```

Source/tool hashes:

| File | SHA-256 |
|:--|:--|
| `research/tools/sparse_ablation.cc` | `b72a51417e73610ddf11b2c6b01915d51b4ed68d9ee56d1e75560d900a778719` |
| `research/collect_sparse_ablation.py` | `c53647e8f41797aba6bcb2ac85accf146bcb5e6d704224ee00db528d41fd59eb` |
| `research/analyze_sparse_ablation.py` | `c20f9ca0cef50cef5fbc933d67f555a90b9b477384f28553db383efbfa281523` |
| `research/tools/numabind0_epyc.c` | `d4c3d27e0fd2278905703f68c5316ae376f10edba30a6739b751014be0176beb` |
| human codon table | `e6c4a49036fe21f3266e7e53130011bd7725c62ebeabbe442f7f8f1cdf5890c4` |

Compiler configuration and dynamic linkage are preserved verbatim in
[`ablation-gxx-version.txt`](ablation-gxx-version.txt),
[`ablation-gxx-verbose.txt`](ablation-gxx-verbose.txt), and
[`ablation-harness-ldd.txt`](ablation-harness-ldd.txt). Their SHA-256 values are respectively
`9eaf9b7f4b11c2e84e2478c2ceb0e4f48f4ba88565bcfc832b3bce49847dda6d`,
`cc20edc2a78805bc1ad73c5b8ecd83844906f82cb3a8ae25ecd06cb2a7dbba7b`, and
`ed1750e4785a0fe06f62fc9a296c0878088e51a9ab76187b85df3d74baa96055`.

## Host and planned environment

The hardware snapshot is preserved as:

| File | SHA-256 |
|:--|:--|
| [`hardware-arrakis-lscpu.json`](hardware-arrakis-lscpu.json) | `8eca4c270e4cc7b967f82832c899022c2af989ae064726db1c2ce216af72d6e8` |
| [`hardware-arrakis-cpu-node.txt`](hardware-arrakis-cpu-node.txt) | `66a319c324b60bfc2392aab3813cbd4753a24eb25b02e689930ce5ffcaaed004` |
| [`hardware-arrakis-uname.txt`](hardware-arrakis-uname.txt) | `eb296fc0404a3c1530e46775eef08de13761a1de76cab6ca8fde6957cd65b7d1` |
| [`hardware-arrakis-memory.txt`](hardware-arrakis-memory.txt) | `d3d9bcb336b6d28cc77a9187ec3540a770391a6736313a9c6b2ad9c1093d664d` |
| [`ablation-python-version.txt`](ablation-python-version.txt) | `f6b75e07f1488db28a89724a522725e3e01af3dc78f6fd365f17eb4059e41056` |

The controlled run explicitly sets:

```text
OMP_PROC_BIND=close
OMP_PLACES=cores
OMP_DYNAMIC=false
OMP_WAIT_POLICY=active
OMP_THREAD_LIMIT=16
```

`active` wait policy is appropriate only on an isolated/reserved node; it should not be used to
claim controlled timing while another job occupies the same CPUs. The harness probes an actual
OpenMP team before timing, and the collector/analyzer require the sparse and dense members of every
pair to report matching effective team sizes and lattice dimensions.

The planned input file hashes after extracting the official archive are P30281
`bc114758eb7e027e37d3761b292a7eb4574aa3c856faead3fa36c032113174c8` and Q6UXY8
`0a59d49b01b7f7745100e8b561c0abf29c1bb5b41d147a7a0e83c0664a7457ba`.

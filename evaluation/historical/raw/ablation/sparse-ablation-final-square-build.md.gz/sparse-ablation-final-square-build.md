# Final square-default sparse/dense ablation build

This record supersedes the historical packed-default build note for the completed
`sparse-ablation-P30281-Q6UXY8-3x-2026-07-14` matrix. The harness was rebuilt from the square-
default source with `LDCLEAN_SQUARE_MEMOS`; the resulting executable is byte-identical to the
hash recorded in every ablation CSV row.

## Build

```text
g++ -std=c++11 -O3 -flto -Wall -fopenmp -DLDCLEAN_SQUARE_MEMOS -Ilineardesign-clean/src \
  research/tools/sparse_ablation.cc \
  lineardesign-clean/src/fold_turner.cc \
  lineardesign-clean/src/energy.cc \
  lineardesign-clean/src/dfa.cc \
  lineardesign-clean/src/codon_table.cc \
  -o /tmp/sparse_ablation-final-square
```

Harness SHA-256: `fb273c580ff8804c1f2cf7b761034dec71cc54b2fcb2fe2a195e29819b8105f3`.

## Source and input hashes

| File | SHA-256 |
|:--|:--|
| `research/tools/sparse_ablation.cc` | `b72a51417e73610ddf11b2c6b01915d51b4ed68d9ee56d1e75560d900a778719` |
| `lineardesign-clean/src/fold_turner.cc` | `ea03c89a7792c0a6851abf625feb93d39323c93da7f8a5f6f2ab378f844f9635` |
| `lineardesign-clean/src/energy.cc` | `b3b873789af2f2b42f41978a5d6aca5015596b787f1548f48d728c6d46d35793` |
| `lineardesign-clean/src/dfa.cc` | `5c9cf51c5bde337431e7cd1877ff14bfcae3d72a7eb1f0ad8e3dd8235291876b` |
| `lineardesign-clean/src/codon_table.cc` | `c789d7d0a686cfc9a7769ce74ed7527f558b6ba372df6e97d8ada2985dd680c1` |
| human codon table | `e6c4a49036fe21f3266e7e53130011bd7725c62ebeabbe442f7f8f1cdf5890c4` |
| NUMA node-0 prefix | `0bbada9fb6e1dda5db30ae218ad0685a371578d80c3c3fae16cac1d73aac8177` |
| completed raw CSV | `254cb24881d302090112133772e060c5271346e1e1087cc5a2d9546a686782ac` |

The collector/analyzer hashes and GNU-time hash remain recorded in the raw summary and the
machine-readable experiment manifest.
